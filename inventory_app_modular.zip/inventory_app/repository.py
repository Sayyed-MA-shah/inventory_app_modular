from typing import List, Optional, Dict, Any
from datetime import datetime
from . import database

def add_color(name: str):
    with database.get_connection() as conn:
        conn.execute("INSERT OR IGNORE INTO colors(name) VALUES(?)", (name.strip(),))

def add_size(name: str):
    with database.get_connection() as conn:
        conn.execute("INSERT OR IGNORE INTO sizes(name) VALUES(?)", (name.strip(),))

def list_colors() -> List[str]:
    with database.get_connection() as conn:
        rows = conn.execute("SELECT name FROM colors ORDER BY name").fetchall()
    return [r[0] for r in rows]

def list_sizes() -> List[str]:
    with database.get_connection() as conn:
        rows = conn.execute("SELECT name FROM sizes ORDER BY name").fetchall()
    return [r[0] for r in rows]

def get_color_id(name: str) -> Optional[int]:
    with database.get_connection() as conn:
        row = conn.execute("SELECT id FROM colors WHERE name=?", (name,)).fetchone()
        return row["id"] if row else None

def get_size_id(name: str) -> Optional[int]:
    with database.get_connection() as conn:
        row = conn.execute("SELECT id FROM sizes WHERE name=?", (name,)).fetchone()
        return row["id"] if row else None

def add_product(name: str, rack: str) -> int:
    with database.get_connection() as conn:
        cur = conn.execute("INSERT INTO products(name, rack_number) VALUES(?,?)", (name.strip(), rack.strip()))
        return cur.lastrowid

def get_or_create_product(name: str, rack: str) -> int:
    with database.get_connection() as conn:
        row = conn.execute("SELECT id FROM products WHERE name=? AND rack_number=?", (name.strip(), rack.strip())).fetchone()
        if row:
            return row["id"]
        cur = conn.execute("INSERT INTO products(name, rack_number) VALUES(?,?)", (name.strip(), rack.strip()))
        return cur.lastrowid

def add_variant(product_id: int, color_id: int, size_id: int, qty: int, retail: float, wholesale: float) -> int:
    with database.get_connection() as conn:
        cur = conn.execute(
            """INSERT OR IGNORE INTO product_variants(product_id, color_id, size_id, quantity, retail_price, wholesale_price)
                 VALUES(?,?,?,?,?,?)""",
            (product_id, color_id, size_id, qty, retail, wholesale)
        )
        if cur.rowcount == 0:
            conn.execute(
                """UPDATE product_variants
                       SET quantity = quantity + ?,
                           retail_price = ?,
                           wholesale_price = ?
                     WHERE product_id=? AND color_id=? AND size_id=?""",
                (qty, retail, wholesale, product_id, color_id, size_id)
            )
            row = conn.execute(
                "SELECT id FROM product_variants WHERE product_id=? AND color_id=? AND size_id=?",
                (product_id, color_id, size_id)
            ).fetchone()
            return row["id"]
        return cur.lastrowid

def list_variants(filters: Dict[str, Any]) -> list:
    sql = """
        SELECT p.name as product, p.rack_number as rack,
               s.name as size, c.name as color,
               v.quantity as qty, v.retail_price as retail, v.wholesale_price as wholesale,
               v.id as vid
          FROM product_variants v
          JOIN products p ON p.id = v.product_id
          JOIN sizes s ON s.id = v.size_id
          JOIN colors c ON c.id = v.color_id
         WHERE 1=1
    """
    params = []
    if filters.get("product"):
        sql += " AND p.name LIKE ?"
        params.append(f"%{filters['product'].strip()}%")
    if filters.get("rack"):
        sql += " AND p.rack_number LIKE ?"
        params.append(f"%{filters['rack'].strip()}%")
    if filters.get("size"):
        sql += " AND s.name = ?"
        params.append(filters["size"])
    if filters.get("color"):
        sql += " AND c.name = ?"
        params.append(filters["color"])
    status = filters.get("status")
    if status == "Low Stock":
        sql += " AND v.quantity BETWEEN 1 AND ?"
        params.append(int(filters.get("low_threshold", 5)))
    elif status == "Out of Stock":
        sql += " AND v.quantity = 0"

    sql += " ORDER BY p.name, rack, size, color"
    with database.get_connection() as conn:
        rows = conn.execute(sql, params).fetchall()
    return [tuple(r) for r in rows]

def restock_units(variant_id: int, units: int):
    with database.get_connection() as conn:
        conn.execute("UPDATE product_variants SET quantity = quantity + ? WHERE id=?", (units, variant_id))

def restock_boxes(variant_id: int, per_box: int, boxes: int):
    restock_units(variant_id, per_box * boxes)

def update_prices(variant_id: int, retail: float, wholesale: float):
    with database.get_connection() as conn:
        conn.execute("UPDATE product_variants SET retail_price=?, wholesale_price=? WHERE id=?", (retail, wholesale, variant_id))

def delete_variant(variant_id: int):
    with database.get_connection() as conn:
        conn.execute("DELETE FROM product_variants WHERE id=?", (variant_id,))

def get_variant(variant_id: int):
    with database.get_connection() as conn:
        return conn.execute(
            """SELECT v.*, p.name as product_name, p.rack_number as rack, s.name as size, c.name as color
                   FROM product_variants v
                   JOIN products p ON p.id=v.product_id
                   JOIN sizes s ON s.id=v.size_id
                   JOIN colors c ON c.id=v.color_id
                  WHERE v.id=?""",
            (variant_id,)
        ).fetchone()

def get_product_id_from_variant(variant_id: int) -> Optional[int]:
    with database.get_connection() as conn:
        row = conn.execute("SELECT product_id FROM product_variants WHERE id=?", (variant_id,)).fetchone()
        return row["product_id"] if row else None

def delete_product(product_id: int):
    with database.get_connection() as conn:
        conn.execute("DELETE FROM products WHERE id=?", (product_id,))

def list_products() -> list:
    with database.get_connection() as conn:
        return conn.execute("SELECT id, name, rack_number FROM products ORDER BY name").fetchall()

def create_invoice(customer_name: str, customer_phone: str, pricing_type: str, tax_rate: float, items: list) -> int:
    from datetime import datetime
    created_at = datetime.now().isoformat(timespec="seconds")
    with database.get_connection() as conn:
        cur = conn.execute(
            """INSERT INTO invoices(customer_name, customer_phone, pricing_type, tax_rate, created_at)
                 VALUES(?,?,?,?,?)""",
            (customer_name.strip(), customer_phone.strip(), pricing_type, float(tax_rate), created_at)
        )
        invoice_id = cur.lastrowid

        for it in items:
            vid = int(it["variant_id"])
            qty = int(it["quantity"])
            vr = conn.execute("SELECT retail_price, wholesale_price, quantity FROM product_variants WHERE id=?", (vid,)).fetchone()
            if not vr:
                raise ValueError(f"Variant {vid} not found")
            unit = vr["retail_price"] if pricing_type == "retail" else vr["wholesale_price"]
            if qty > vr["quantity"]:
                raise ValueError(f"Not enough stock for variant id {vid}")
            line_total = unit * qty
            conn.execute(
                """INSERT INTO invoice_items(invoice_id, variant_id, quantity, unit_price, line_total)
                     VALUES(?,?,?,?,?)""",
                (invoice_id, vid, qty, unit, line_total)
            )
            conn.execute("UPDATE product_variants SET quantity = quantity - ? WHERE id=?", (qty, vid))
    return invoice_id

def get_invoice(invoice_id: int):
    with database.get_connection() as conn:
        inv = conn.execute("SELECT * FROM invoices WHERE id=?", (invoice_id,)).fetchone()
        items = conn.execute(
            """SELECT ii.*, p.name as product, s.name as size, c.name as color, pr.rack_number as rack
                   FROM invoice_items ii
                   JOIN product_variants v ON v.id=ii.variant_id
                   JOIN products pr ON pr.id=v.product_id
                   JOIN sizes s ON s.id=v.size_id
                   JOIN colors c ON c.id=v.color_id
                   JOIN products p ON p.id=v.product_id
                  WHERE ii.invoice_id=?""",
            (invoice_id,)
        ).fetchall()
    return inv, items
