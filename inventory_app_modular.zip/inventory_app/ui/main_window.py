import tkinter as tk
from tkinter import ttk, Menu, messagebox
from .. import repository as repo
from .dialogs import AddColorDialog, AddSizeDialog, AddProductDialog, AddVariantDialog
from .invoice_window import InvoiceWindow

class MainWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Inventory Management System")
        self.geometry("1100x600")
        self._build_menu()
        self._build_layout()
        self.load_variants()

    def _build_menu(self):
        menubar = Menu(self)
        self.config(menu=menubar)

        m_add = Menu(menubar, tearoff=0)
        m_add.add_command(label="Color", command=lambda: AddColorDialog(self))
        m_add.add_command(label="Size", command=lambda: AddSizeDialog(self))
        m_add.add_separator()
        m_add.add_command(label="New Product", command=lambda: (AddProductDialog(self), self.after(100, self.load_variants)))
        menubar.add_cascade(label="ADD", menu=m_add)

        m_inv = Menu(menubar, tearoff=0)
        m_inv.add_command(label="New Invoice", command=lambda: (InvoiceWindow(self), self.after(500, self.load_variants)))
        menubar.add_cascade(label="Invoices", menu=m_inv)

        m_rep = Menu(menubar, tearoff=0)
        m_rep.add_command(label="Low Stock (<=5)", command=self.filter_low_stock)
        m_rep.add_command(label="Out of Stock", command=self.filter_out_stock)
        menubar.add_cascade(label="Reports", menu=m_rep)

    def _build_layout(self):
        left = tk.Frame(self, bd=1, relief="sunken")
        left.pack(side="left", fill="both", expand=True, padx=8, pady=8)

        filt = tk.LabelFrame(left, text="Search & Filter")
        filt.pack(fill="x", padx=8, pady=8)
        tk.Label(filt, text="Product").grid(row=0, column=0, padx=4, pady=4, sticky="e")
        tk.Label(filt, text="Rack").grid(row=0, column=2, padx=4, pady=4, sticky="e")
        tk.Label(filt, text="Size").grid(row=1, column=0, padx=4, pady=4, sticky="e")
        tk.Label(filt, text="Color").grid(row=1, column=2, padx=4, pady=4, sticky="e")
        tk.Label(filt, text="Status").grid(row=0, column=4, padx=4, pady=4, sticky="e")

        self.product_e = tk.Entry(filt, width=20)
        self.product_e.grid(row=0, column=1, padx=4, pady=4)
        self.rack_e = tk.Entry(filt, width=12)
        self.rack_e.grid(row=0, column=3, padx=4, pady=4)
        self.size_cb = ttk.Combobox(filt, values=repo.list_sizes(), width=12, state="readonly")
        self.size_cb.grid(row=1, column=1, padx=4, pady=4)
        self.color_cb = ttk.Combobox(filt, values=repo.list_colors(), width=12, state="readonly")
        self.color_cb.grid(row=1, column=3, padx=4, pady=4)

        self.status_cb = ttk.Combobox(filt, values=["All","Low Stock","Out of Stock"], width=14, state="readonly")
        self.status_cb.current(0)
        self.status_cb.grid(row=0, column=5, padx=4, pady=4)

        ttk.Button(filt, text="Apply", command=self.apply_filters).grid(row=0, column=6, padx=6, pady=4)
        ttk.Button(filt, text="Clear", command=self.clear_filters).grid(row=1, column=6, padx=6, pady=4)

        self.tree = ttk.Treeview(left, columns=("product","rack","size","color","qty","retail","wholesale","vid"),
                                 show="headings", height=20)
        for i, (col, w) in enumerate([("Product",220),("Rack",80),("Size",80),("Color",90),("Qty",60),("Retail",80),("Wholesale",90)]):
            self.tree.heading(i, text=col)
            self.tree.column(i, width=w, anchor='w' if i not in (4,5,6) else 'e')
        self.tree["displaycolumns"] = (0,1,2,3,4,5,6)  # hide vid
        self.tree.pack(fill="both", expand=True, padx=8, pady=(0,8))
        self.tree.bind("<<TreeviewSelect>>", self.on_tree_select)

        right = tk.LabelFrame(self, text="Actions")
        right.pack(side="right", fill="y", padx=8, pady=8)

        tk.Label(right, text="Restock (units)").pack(anchor="w", padx=8, pady=(8,2))
        rf = tk.Frame(right); rf.pack(padx=8, pady=2, anchor="w")
        self.restock_units_e = tk.Entry(rf, width=8); self.restock_units_e.insert(0, "1"); self.restock_units_e.pack(side="left", padx=4)
        ttk.Button(rf, text="Add Units", command=self.restock_units).pack(side="left", padx=4)

        tk.Label(right, text="Restock by Box").pack(anchor="w", padx=8, pady=(10,2))
        bf = tk.Frame(right); bf.pack(padx=8, pady=2, anchor="w")
        tk.Label(bf, text="Items/Box").pack(side="left")
        self.per_box_e = tk.Entry(bf, width=6); self.per_box_e.insert(0, "12"); self.per_box_e.pack(side="left", padx=4)
        tk.Label(bf, text="Boxes").pack(side="left")
        self.boxes_e = tk.Entry(bf, width=6); self.boxes_e.insert(0, "1"); self.boxes_e.pack(side="left", padx=4)
        ttk.Button(right, text="Add Boxes", command=self.restock_boxes).pack(padx=8, pady=6, anchor="w")

        tk.Label(right, text="Update Prices").pack(anchor="w", padx=8, pady=(10,2))
        pf = tk.Frame(right); pf.pack(padx=8, pady=2, anchor="w")
        tk.Label(pf, text="Retail").pack(side="left")
        self.retail_e = tk.Entry(pf, width=8); self.retail_e.pack(side="left", padx=4)
        tk.Label(pf, text="Wholesale").pack(side="left")
        self.wholesale_e = tk.Entry(pf, width=8); self.wholesale_e.pack(side="left", padx=4)
        ttk.Button(right, text="Save Prices", command=self.update_prices).pack(padx=8, pady=6, anchor="w")

        ttk.Separator(right, orient="horizontal").pack(fill="x", padx=8, pady=8)

        ttk.Button(right, text="Add Variant to Selected Product", command=self.open_add_variant).pack(padx=8, pady=4, anchor="w")
        ttk.Button(right, text="Delete Variant", command=self.delete_selected_variant).pack(padx=8, pady=4, anchor="w")

    def get_selected_vid(self):
        sel = self.tree.selection()
        if not sel: return None
        values = self.tree.item(sel[0], "values")
        vid = values[-1] if values else None
        try:
            return int(vid)
        except (TypeError, ValueError):
            return None

    def on_tree_select(self, _evt=None):
        vid = self.get_selected_vid()
        if not vid: return
        row = repo.get_variant(vid)
        if row:
            self.retail_e.delete(0, tk.END); self.retail_e.insert(0, str(row["retail_price"]))
            self.wholesale_e.delete(0, tk.END); self.wholesale_e.insert(0, str(row["wholesale_price"]))

    def load_variants(self):
        for r in self.tree.get_children():
            self.tree.delete(r)
        rows = repo.list_variants({
            "product": self.product_e.get().strip(),
            "rack": self.rack_e.get().strip(),
            "size": self.size_cb.get().strip() if self.size_cb.get() else None,
            "color": self.color_cb.get().strip() if self.color_cb.get() else None,
            "status": self.status_cb.get(),
            "low_threshold": 5
        })
        for row in rows:
            self.tree.insert("", "end", values=row)

    def apply_filters(self):
        self.load_variants()

    def clear_filters(self):
        self.product_e.delete(0, tk.END); self.rack_e.delete(0, tk.END)
        self.size_cb.set(""); self.color_cb.set("")
        self.status_cb.set("All"); self.load_variants()

    def filter_low_stock(self):
        self.status_cb.set("Low Stock"); self.load_variants()

    def filter_out_stock(self):
        self.status_cb.set("Out of Stock"); self.load_variants()

    def restock_units(self):
        vid = self.get_selected_vid()
        if not vid: messagebox.showwarning("Select", "Select a variant row first"); return
        try:
            units = int(self.restock_units_e.get().strip()); assert units > 0
        except Exception:
            messagebox.showerror("Error", "Enter a positive units number"); return
        repo.restock_units(vid, units); self.load_variants()

    def restock_boxes(self):
        vid = self.get_selected_vid()
        if not vid: messagebox.showwarning("Select", "Select a variant row first"); return
        try:
            per_box = int(self.per_box_e.get().strip()); boxes = int(self.boxes_e.get().strip())
            assert per_box > 0 and boxes > 0
        except Exception:
            messagebox.showerror("Error", "Enter positive integers for items/box and boxes"); return
        repo.restock_boxes(vid, per_box, boxes); self.load_variants()

    def update_prices(self):
        vid = self.get_selected_vid()
        if not vid: messagebox.showwarning("Select", "Select a variant row first"); return
        try:
            retail = float(self.retail_e.get().strip()); wholesale = float(self.wholesale_e.get().strip())
        except ValueError:
            messagebox.showerror("Error", "Enter numeric prices"); return
        repo.update_prices(vid, retail, wholesale); self.load_variants()

    def open_add_variant(self):
        vid = self.get_selected_vid()
        if not vid: messagebox.showwarning("Select", "Select a variant row first"); return
        pid = repo.get_product_id_from_variant(vid)
        if not pid: messagebox.showerror("Error", "Could not resolve product from selection"); return
        AddVariantDialog(self, pid)

    def delete_selected_variant(self):
        vid = self.get_selected_vid()
        if not vid: messagebox.showwarning("Select", "Select a variant row first"); return
        if messagebox.askyesno("Confirm", "Delete this variant?"):
            repo.delete_variant(vid); self.load_variants()
