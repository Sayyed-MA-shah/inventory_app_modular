import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
from .. import repository as repo
from ..utils.pdf_export import export_invoice

class InvoiceWindow(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("Create Invoice")
        self.geometry("900x500")

        # Left: variant list
        left = tk.Frame(self)
        left.pack(side="left", fill="both", expand=True, padx=6, pady=6)

        filt = tk.Frame(left)
        filt.pack(fill="x")
        tk.Label(filt, text="Search product").pack(side="left")
        self.search_e = tk.Entry(filt, width=24)
        self.search_e.pack(side="left", padx=4)
        ttk.Button(filt, text="Filter", command=self.load_variants).pack(side="left")
        ttk.Button(filt, text="Clear", command=self.clear_filter).pack(side="left", padx=2)

        self.tree = ttk.Treeview(left, columns=("product","rack","size","color","qty","retail","wholesale","vid"),
                                 show="headings", height=15)
        for i, (col, w) in enumerate([("Product",180),("Rack",80),("Size",80),("Color",80),("Qty",60),("Retail",80),("Wholesale",90)]):
            self.tree.heading(i, text=col)
            self.tree.column(i, width=w, anchor='w' if i not in (4,5,6) else 'e')
        self.tree["displaycolumns"] = (0,1,2,3,4,5,6)
        self.tree.pack(fill="both", expand=True, pady=6)

        # Right: cart + details
        right = tk.Frame(self, bd=1, relief="groove")
        right.pack(side="right", fill="y", padx=6, pady=6)

        tk.Label(right, text="Customer Name").pack(anchor="w", padx=8, pady=(8,2))
        self.cust_name = tk.Entry(right, width=28)
        self.cust_name.pack(padx=8, pady=2)

        tk.Label(right, text="Customer Phone").pack(anchor="w", padx=8, pady=(8,2))
        self.cust_phone = tk.Entry(right, width=28)
        self.cust_phone.pack(padx=8, pady=2)

        self.price_var = tk.StringVar(value="retail")
        tk.Label(right, text="Pricing").pack(anchor="w", padx=8, pady=(8,2))
        tk.Radiobutton(right, text="Retail", variable=self.price_var, value="retail").pack(anchor="w", padx=8)
        tk.Radiobutton(right, text="Wholesale", variable=self.price_var, value="wholesale").pack(anchor="w", padx=8)

        tk.Label(right, text="Tax %").pack(anchor="w", padx=8, pady=(8,2))
        self.tax_e = tk.Entry(right, width=10)
        self.tax_e.insert(0, "0")
        self.tax_e.pack(padx=8, pady=2)

        # Cart area
        tk.Label(right, text="Cart").pack(anchor="w", padx=8, pady=(8,2))
        self.cart = ttk.Treeview(right, columns=("product","size","color","qty","unit","total","vid"),
                                 show="headings", height=8)
        for i,(col,w) in enumerate([("Product",160),("Size",70),("Color",70),("Qty",50),("Unit",70),("Total",80)]):
            self.cart.heading(i, text=col)
            self.cart.column(i, width=w, anchor='e' if i>=3 else 'w')
        self.cart["displaycolumns"] = (0,1,2,3,4,5)
        self.cart.pack(padx=8, pady=4)

        # Controls
        qty_frame = tk.Frame(right)
        qty_frame.pack(padx=8, pady=(6,2), fill="x")
        tk.Label(qty_frame, text="Qty to add").pack(side="left")
        self.add_qty_e = tk.Entry(qty_frame, width=6)
        self.add_qty_e.insert(0, "1")
        self.add_qty_e.pack(side="left", padx=4)
        ttk.Button(qty_frame, text="Add Selected", command=self.add_selected_to_cart).pack(side="left", padx=4)

        # Totals + actions
        self.total_var = tk.StringVar(value="Total: 0.00")
        tk.Label(right, textvariable=self.total_var, font=("TkDefaultFont", 10, "bold")).pack(padx=8, pady=6)

        ttk.Button(right, text="Generate Invoice", command=self.generate_invoice).pack(padx=8, pady=6)

        self.load_variants()

    def clear_filter(self):
        self.search_e.delete(0, tk.END)
        self.load_variants()

    def load_variants(self):
        for r in self.tree.get_children():
            self.tree.delete(r)
        rows = repo.list_variants({"product": self.search_e.get().strip()})
        for row in rows:
            self.tree.insert("", "end", values=row)

    def add_selected_to_cart(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Select", "Select a variant to add")
            return
        qty = self.add_qty_e.get().strip()
        try:
            qty = int(qty)
            if qty <= 0:
                raise ValueError()
        except ValueError:
            messagebox.showerror("Error", "Quantity must be a positive integer")
            return
        item = self.tree.item(sel[0])["values"]
        product,size,color = item[0], item[2], item[3]
        avail = int(item[4])
        unit = float(item[5] if self.price_var.get()=="retail" else item[6])
        vid = int(item[-1])

        if qty > avail:
            messagebox.showerror("Error", f"Only {avail} available")
            return

        total = unit * qty
        self.cart.insert("", "end", values=(product,size,color,qty,f"{unit:.2f}", f"{total:.2f}", vid))
        self.update_total_label()

    def update_total_label(self):
        total = 0.0
        for iid in self.cart.get_children():
            vals = self.cart.item(iid)["values"]
            total += float(vals[5])
        try:
            tax = float(self.tax_e.get().strip() or 0.0)
        except ValueError:
            tax = 0.0
        grand = total * (1 + tax/100.0)
        self.total_var.set(f"Total: {grand:.2f} (incl tax)")

    def generate_invoice(self):
        items = []
        for iid in self.cart.get_children():
            vals = self.cart.item(iid)["values"]
            items.append({"variant_id": int(vals[-1]), "quantity": int(vals[3])})
        if not items:
            messagebox.showwarning("Empty", "Add items to cart")
            return
        try:
            inv_id = repo.create_invoice(
                self.cust_name.get().strip(),
                self.cust_phone.get().strip(),
                self.price_var.get(),
                float(self.tax_e.get().strip() or 0.0),
                items
            )
            inv, inv_items = repo.get_invoice(inv_id)
            out = export_invoice(inv, inv_items, Path(__file__).resolve().parents[1] / "exports")
            messagebox.showinfo("Saved", f"Invoice {inv_id} saved to:\n{out}")
            self.destroy()
        except Exception as e:
            messagebox.showerror("Error", str(e))
